# Buildkite Agent OSS Attributions

The Buildkite Agent would not be possible without open-source software.

Normally, there would be a large list of open-source licenses and notices for
the third-party software used in the Buildkite Agent here.

If you are reading this, either you have downloaded the agent source code,
or you or someone else built the agent without using `scripts/build-binary.sh`. 
In that case, Buildkite didn't distribute any third-party libraries to you :-)

You can generate a summary of licenses of dependencies with the `go-licenses`
command (see `scripts/generate-acknowledgements.sh` for an example).
